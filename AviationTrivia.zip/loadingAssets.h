
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>

sf::Texture playButtonTexture;
sf::Texture shrimpTexture;
sf::Texture vSPTexture;
sf::Texture moreButtonTexture;
sf::Texture exitButtonTexture;
sf::Texture fontTexture;
sf::Texture selectionBoxTexture;
sf::Texture statsButtonTexture;
sf::Texture m1BackgroundTexture;
sf::Texture questionBoxTexture;
sf::Texture gameBackgroundTexture;
sf::Texture feedbackButtonTexture;
sf::Texture moreGamesTexture;
sf::Texture arrowTexture;
sf::Texture creditsButtonTexture;
sf::Texture boxTexture;
sf::Texture howToPlayTexture;
sf::Texture howManyQuestionsTexture;
sf::Texture confirmTexture;
sf::Texture settingsTexture;
sf::Texture checkBoxTexture;
sf::Texture resetTexture;
sf::Texture volumeTexture;
sf::Texture marketTexture;
sf::Texture saveIconTexture;
sf::Texture questionCounterTexture;

sf::Music introMusic;
sf::Music menuMusic;

bool loadAssets() {
	bool problem = false;

	if (!playButtonTexture.loadFromFile("playButton.png")) {
		std::cout << "Could not load play button sprite sheet! Make sure you have <<playButton.png>>\n";
		problem = true;
	}
	if (!shrimpTexture.loadFromFile("shrimp.png")) {
		std::cout << "Couldn't load shrimp texture! Make sure you have <<shrimp.png>>n";
		problem = true;
	}
	if (!vSPTexture.loadFromFile("introtext.png")) {
		std::cout << "Couldn't load intro text texture! Make sure you have <<introtext.png>>\n";
		problem = true;
	}
	if (!moreButtonTexture.loadFromFile("moreButton.png")) {
		std::cout << "Couldn't load more button texture! Make sure you have <<moreButton.png>>\n";
		problem = true;
	}
	if (!exitButtonTexture.loadFromFile("exitButton.png")) {
		std::cout << "Couldn't load exit button texture! Make sure you have <<exitButton.png>>\n";
		problem = true;
	}
	if (!fontTexture.loadFromFile("font.png")) {
		std::cout << "Couldn't load font texture! Make sure you have <<font.png>>\n";
		problem = true;
	}
	if (!selectionBoxTexture.loadFromFile("selectionBox.png")) {
		std::cout << "Couldn't load selection box texture! Make sure you have <<selectionBox.png>>\n";
		problem = true;
	}
	if (!statsButtonTexture.loadFromFile("statsButton.png")) {
		std::cout << "Couldn't load stats button texture! Make sure you have <<statsButton.png>>\n";
		problem = true;
	}
	if (!m1BackgroundTexture.loadFromFile("menu1Background.png")) {
		std::cout << "Couldn't load menu 1 background texture! Make sure you have <<menu1Background.png>>\n";
		problem = true;
	}
	if (!questionBoxTexture.loadFromFile("questionBox.png")) {
		std::cout << "Couldn't load question box texture! Make sure you have <<questionBox.png>>\n";
		problem = true;
	}
	if (!gameBackgroundTexture.loadFromFile("gameBackground.png")) {
		std::cout << "Couldn't load game background texture! Make sure you have <<gameBackground.png>>\n";
		problem = true;
	}
	if (!feedbackButtonTexture.loadFromFile("feedbackButton.png")) {
		std::cout << "Couldn't load feedback button texture! Make sure you have <<feedbackButtonButton.png>>\n";
		problem = true;
	}
	if (!moreGamesTexture.loadFromFile("moreGamesButton.png")) {
		std::cout << "Couldn't load more games texture! Make sure you have <<moreGamesButton.png>>\n";
		problem = true;
	}
	if (!arrowTexture.loadFromFile("arrow.png")) {
		std::cout << "Couldn't load arrow texture! Make sure you have <<arrow.png>>\n";
		problem = true;
	}
	if (!creditsButtonTexture.loadFromFile("creditsButton.png")) {
		std::cout << "Couldn't load credits button texture! Make sure you have <<creditsButton.png>>\n";
		problem = true;
	}
	if (!boxTexture.loadFromFile("box.png")) {
		std::cout << "Couldn't load box texture! Make sure you have <<Box.png>>\n";
		problem = true;
	}
	if (!howToPlayTexture.loadFromFile("howToPlay.png")) {
		std::cout << "Couldn't load how to play texture! Make sure you have <<howToPlay.png>>\n";
		problem = true;
	}
	if (!howManyQuestionsTexture.loadFromFile("howManyQuestions.png")) {
		std::cout << "Couldn't load how many questions texture! Make sure you have <<howManyQuestions.png>>\n";
		problem = true;
	}
	if (!confirmTexture.loadFromFile("confirm.png")) {
		std::cout << "Couldn't load confirm texture! Make sure you have <<confirm.png>>\n";
		problem = true;
	}
	if (!settingsTexture.loadFromFile("settings.png")) {
		std::cout << "Couldn't load settings texture! Make sure you have <<settings.png>>\n";
		problem = true;
	}
	if (!checkBoxTexture.loadFromFile("checkBox.png")) {
		std::cout << "Couldn't load check box texture! Make sure you have <<checkBox.png>>\n";
		problem = true;
	}
	if (!resetTexture.loadFromFile("reset.png")) {
		std::cout << "Couldn't load reset texture! Make sure you have <<reset.png>>\n";
		problem = true;
	}
	if (!volumeTexture.loadFromFile("volume.png")) {
		std::cout << "Couldn't load volume texture! Make sure you have <<volume.png>>\n";
		problem = true;
	}
	if (!marketTexture.loadFromFile("market.png")) {
		std::cout << "Couldn't load market texture! Make sure you have <<market.png>>\n";
		problem = true;
	}
	if (!saveIconTexture.loadFromFile("saveIcon.png")) {
		std::cout << "Couldn't load save icon texture! Make sure you have <<saveIcon.png>>\n";
		problem = true;
	}
	if (!questionCounterTexture.loadFromFile("questionCounter.png")) {
		std::cout << "Couldn't load question counter texture! Make sure you have <<questionCounter.png>>\n";
		problem = true;
	}
	if (!introMusic.openFromFile("Vehicle - OGA - Siberian Intro.wav")) {
		std::cout << "Couldn't open intro music! Make sure you have <<Vehicle - OGA - Siberian Intro.wav>>\n";
		problem = true;
	}
	if (!menuMusic.openFromFile("chilllofir-loop.ogg")) {
		std::cout << "Couldn't open menu music! Make sure you have <<chilllofir-loop.ogg>>\n";
		problem = true;
	}

	vSPTexture.setSmooth(false);
	moreButtonTexture.setSmooth(false);
	exitButtonTexture.setSmooth(false);
	fontTexture.setSmooth(false);
	selectionBoxTexture.setSmooth(false);
	statsButtonTexture.setSmooth(false);
	m1BackgroundTexture.setSmooth(false);
	questionBoxTexture.setSmooth(false);
	gameBackgroundTexture.setSmooth(false);
	feedbackButtonTexture.setSmooth(false);
	moreGamesTexture.setSmooth(false);
	arrowTexture.setSmooth(false);
	creditsButtonTexture.setSmooth(false);
	boxTexture.setSmooth(false);
	howToPlayTexture.setSmooth(false);
	howManyQuestionsTexture.setSmooth(false);
	confirmTexture.setSmooth(false);
	settingsTexture.setSmooth(false);
	checkBoxTexture.setSmooth(false);
	resetTexture.setSmooth(false);
	volumeTexture.setSmooth(false);
	marketTexture.setSmooth(false);
	saveIconTexture.setSmooth(false);
	playButtonTexture.setSmooth(false);
	shrimpTexture.setSmooth(false);
	questionCounterTexture.setSmooth(false);

	menuMusic.setLooping(true);



	return problem;
}

